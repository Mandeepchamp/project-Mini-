package service;

import java.sql.SQLException;

import Exception.NmExcep;
import data.DataClass;

public interface ServInter {

	float checkBal(long account);

	float deposit(long account, float depAmt);

	float withdraw(float withAmt, long account) throws SQLException;

	float transfer(long account, long acc2, float transAmt);

	boolean createAccount(DataClass dc);
	
    void nameCheck(String name) throws NmExcep;
	
	

}
