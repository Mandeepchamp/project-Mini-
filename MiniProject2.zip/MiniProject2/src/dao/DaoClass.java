package dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import data.DataClass;

public class DaoClass implements DaoInter {
	DataClass dc;
	@Override
	public boolean custInfo(DataClass dc) {
		Connection con=null;
		boolean b=false;
 
		try {
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/db","root","root");
			String sql="insert into DataClass values('"+dc.getName()+"',"+dc.getAccount()+","+dc.getBal()+","+dc.getPhone()+")";
			PreparedStatement ps=con.prepareStatement(sql);
			ps.executeUpdate(sql);
			b=true;
			con.close();
		}catch(SQLException e) {
		e.printStackTrace();	
		}
		return b;
	}
	@Override
	public float checkBal(Long account)
	{
		Connection con=null;
		Long Newbalance=0L;
		try {
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/db","root","root");
			String sql1="select account from DataClass";
			PreparedStatement ps1=con.prepareStatement(sql1);
			ResultSet rs1=ps1.executeQuery(sql1);
			while(rs1.next())
			{
				if(rs1.getLong("account")==account)
				{
					break;
				}
				else
					Newbalance=null;
			}
			String sql="select bal from DataClass where account="+account;
			PreparedStatement ps=con.prepareStatement(sql);
			ResultSet rs=ps.executeQuery(sql);
			
			while(rs.next())
			{
				Newbalance=rs.getLong("bal");
				rs.next();
		}
			con.close();
			}catch(SQLException e) {
 
		}
		return Newbalance;
	}
	@Override
	public float withAm(float withAt, long account) throws SQLException
	{
 
		Connection con=null;
		Long Newbalance=0L;
		try {
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/db","root","root");
			String sql1="select * from DataClass";
			PreparedStatement ps1=con.prepareStatement(sql1);
			ResultSet rs1=ps1.executeQuery(sql1);
			while(rs1.next())
			{
				if(rs1.getLong("account")==account)
				{
					break;
 
				}
				else 
				{
					Newbalance=null;
				}
			}
 
			String sql="update DataClass set bal=bal-"+account+" where account="+account;
			PreparedStatement ps=con.prepareStatement(sql);
			ps.executeUpdate(sql);
			
			String s="select bal from DataClass where account="+account;
			PreparedStatement p=con.prepareStatement(s);
			ResultSet rs=p.executeQuery(s);
			while(rs.next())
			{
			Newbalance=rs.getLong("bal");	
			}
			con.close();
 
	}
		catch(SQLException e)
		{
			throw e;
		}
		return Newbalance;
	}
	@Override
	public float transfer(long account, long acc2, float transAmt)
	{
		Connection con=null;
		Long Newbalance=0L;
		try {
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/db","root","root");
			String sql1="select account from DataClass";
			PreparedStatement ps1=con.prepareStatement(sql1);
			ResultSet rs1=ps1.executeQuery(sql1);
			while(rs1.next())
			{
				if(rs1.getLong("account")==account)
				{
					break;
				}
				else {
					Newbalance=null;
				throw new SQLException();
			}
			}
		String sql="update DataClass set bal=bal-"+transAmt+" where account="+account;
		PreparedStatement ps=con.prepareStatement(sql);
		ps.executeUpdate(sql);
 
		String sql2="select account from DataClass";
		PreparedStatement ps2=con.prepareStatement(sql2);
		ResultSet rs2=ps2.executeQuery(sql2);
		while(rs2.next())
		{
			if(rs2.getLong("account")==acc2)
			{
				break;
			}
			else {
				Newbalance=null;
			throw new SQLException();
 
		}}
		String s="update DataClass set bal=bal+"+transAmt+" where account="+acc2;
		PreparedStatement p=con.prepareStatement(s);
		p.executeUpdate(s);
 
		String s2="select bal from DataClass where account="+account;
		PreparedStatement p2=con.prepareStatement(s2);
		ResultSet rs=p2.executeQuery(s2);
		while(rs.next())
		{
		Newbalance=rs.getLong("bal");	
		}
		con.close();
 
}
	catch(SQLException e)
	{
		e.printStackTrace();
	}
	return Newbalance;
}
	@Override
	public float depoAmt(long account, float depAmt) 
	{
		Connection con=null;
		Long Newbalance=0L;
		try {
		con=DriverManager.getConnection("jdbc:mysql://localhost:3306/db","root","root");
		String sql="update DataClass set bal=bal+"+depAmt+" where account= "+account;
		PreparedStatement ps=con.prepareStatement(sql);
		ps.executeUpdate(sql);
		
		String s2="select bal from DataClass where account="+account;
		PreparedStatement p2=con.prepareStatement(s2);
		ResultSet rs=p2.executeQuery(s2);
		while(rs.next())
		{
		Newbalance=rs.getLong("bal");	
		}
		con.close();
 
}
	catch(SQLException e)
	{
		e.printStackTrace();
	}
	return Newbalance;
	}
}
 
